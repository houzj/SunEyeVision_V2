using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Loader;
using System.Security.Cryptography;
using System.Text.Json;
internal static class ReleaseBootstrap {
 internal static void Initialize() {
  var root=Environment.GetEnvironmentVariable("S1_PRODUCT_ROOT") ?? throw new Exception("Missing official product root");
  Environment.SetEnvironmentVariable("PATH",root+";"+Path.Combine(root,"runtimes","win-x64","native")+";"+Environment.GetEnvironmentVariable("PATH"));
  AssemblyLoadContext.Default.Resolving+=(_,name)=>{
   var candidates=new[]{Path.Combine(root,name.Name+".dll"),Path.Combine(root,"plugins",name.Name!,name.Name+".dll"),Path.Combine(root,"plugins","SunEyeVision.Tool.BlobAnalysis",name.Name+".dll")};
   foreach(var path in candidates)if(File.Exists(path))return AssemblyLoadContext.Default.LoadFromAssemblyPath(path);
   if(!name.Name!.StartsWith("SunEyeVision.") && Environment.GetEnvironmentVariable("S1_TEST_HELPERS") is string helper){var p=Path.Combine(helper,name.Name+".dll");if(File.Exists(p))return AssemblyLoadContext.Default.LoadFromAssemblyPath(p);}
   return null;
  };
  AppDomain.CurrentDomain.ProcessExit+=(_,__)=>{
   var loaded=AppDomain.CurrentDomain.GetAssemblies().Where(a=>!a.IsDynamic && a.GetName().Name!.StartsWith("SunEyeVision.") && !a.GetName().Name!.EndsWith(".Tests")).Select(a=>new{assembly=a.GetName().Name,path=a.Location,sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(a.Location)))}).ToArray();
   File.WriteAllLines(Path.Combine(Environment.GetEnvironmentVariable("S1_CASE_ROOT")!,"loaded-product.tsv"),loaded.Select(a=>a.assembly+"\t"+a.path+"\t"+a.sha256));
   if(loaded.Any(a=>!Path.GetFullPath(a.path).StartsWith(Path.GetFullPath(root)+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase)))Environment.ExitCode=2;
  };
 }
}