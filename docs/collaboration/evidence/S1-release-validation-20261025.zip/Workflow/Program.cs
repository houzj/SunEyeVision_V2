
internal static class Cases { public static async Task<int> Run(string[] args) {
return await WorkflowCases.Run();
} }