# S3 Blob 框架依赖与结果所有权证据

状态：完成静态证据核对；没有运行 VisionMaster 或 SDK。证据等级仅为原始已安装程序集、XML 和反编译源码静态观察，不能等同宿主运行验证。

## 结论

1. Blob 工具托管壳 `IMVSBlobFindModuCs.dll` 是 .NET Framework 4.6.1、AnyCPU、IL-only 程序集；直接 AssemblyRef 只有 `mscorlib`、`VM.Core`、`VM.PlatformSDKCS`。REA 元数据检查记录 294 个方法、覆盖状态 partial（无解析错误，仍不能把 metadata inspection 当作所有方法源码审阅）。程序集 SHA256 `3106af2e9344a97288553bfbbfa86afd81e2384188b452734f56825f63e0a78d`，MVID `1d550689-0379-4822-8b69-8713d2324342`。REA：`ev_22697cccc2f26bd806da658c3f0a7217a16a9f900a5ac474834b84a33f904f6d`（程序集身份）；`ev_e2d94e338072eadedce0ed9e7457dd6c1ba8a132cde53efffa114c40611eb364`（成员/CIL 锚点，partial）。
2. 原始 `IMVSBlobFindModuTool.Run()` 的 CIL 是 23 字节，直接取 `serverSDKManager.mModuleManager` 和 `ID`，调用 `SyncSelfRun(ID)`；其成员调用和 IL hash 已通过 REA 从该原始 DLL 提取。IL SHA256 `44dee5f9ad426d3e6eaea760a17a441e2a92c539d4078e228efee09f849c6244`。ILSpy 对同一原始二进制的定点反编译也显示该函数只有此调用。可证这是 SDK 自执行入口，不是工具专属配置 UI 的入口。
3. VMControls.WPF 的 `ProcedureConfigControl.OpenParamsTabControl` 会尝试装载同名 `${ModuleTypeName}Control.dll`；找不到可用 `TabWinBase` 时使用通用 `ParamsTabControlBase`。所以专用 Control DLL 在源码分派上是可选的，配置窗口仍可以走通用编辑器。该函数先校验模块目录中的 `${ModuleTypeName}.xml`、`AlgorithmTab.xml`、`Display.xml`；这只证明配置窗口路径的文件门槛。静态源码支持“工具执行入口不依赖专用编辑器”的架构判断，但未通过移除 Control DLL 的真实 VM 会话做运行验证。
4. `VM.Core` 与 `VM.PlatformSDKCS` 是工具壳的两条直接框架依赖。当前 VM.Core 原程序集除平台 SDK 外还直接引用 `WindowsBase`、`PresentationCore`、`VM.Controls`、`VMControls.Interface`、`VMControls.BaseInterface`、`Apps.UIHelper` 等，说明其依赖闭包含 UI/framework 类型；因此“没有专用工具编辑器”不等于“脱离 VM/Core/WPF 即可独立运行”。VM.Core：SHA `936763f6c8a1bf9fcf59f22acebca8feb09b5f3d5701ae77c82bdc81e626190d`，MVID `290025bc-e040-4cd5-94dd-cd49b9af9c99`，REA 元数据 `ev_758f593356d11c17370747b341d4b1992a0fe8ab3fd3176f70d4a6831c3d8517`。VMControls.WPF：SHA `99ffa401c8784472913ad43813d68a8a5577890c00e149506e3e5664fa61c97d`，REA 元数据 `ev_3eb1fd75ae8c1c32c6ae332a1cf0b6d1ea816b3794cf22eee230719d5af4dcd6`。
5. SDK 执行/查询调用链静态可追至 native bridge：`ModuleManager.SyncSelfRun` 按 ID 清对应等待标志，调用 `ServerSDKAPI.IMVS_SelfExecuteOneModule`，检查模块状态并 `PrecisionWait`；Blob 壳的 `ModuResult` getter 调 `QueryModuleOneResult(ID)`，后者调用 `IMVS_QueryModuleHistoryResult(handle, ID, 0, 1, ...)`，将返回指针转结构，再交 `ModuleResultManager.SetModuleResult`。SDK API 对应 P/Invoke 有声明，但 REA 边界检查只证明托管导入声明：SDK 原件 SHA `34c0c90b00cb75a701685b96670b6490f61376f62eacc0ab29d240157db401c1`，MVID `e7b3a3b0-7083-486a-8ca2-97cecec02ea2`，237 个 P/Invoke、4 个 ModuleRef（含 `iMVS-6000PlatformSDK.dll`）；REA `ev_3d164ee62a60810882e6c7885ea294d96fd5dc0b2cef93878d1aab1c2a296d5f`。这还没有把 native SDK 如何发现/装载 Blob 算法 DLL 的具体代码路径闭合。
6. 原生 Blob 模块二进制已定位：`IMVSBlobFindModu.dll` SHA `4de695d8c3051045c9010739686f94c32d66a36ee486207fe749fb183fff4c9a`；相邻原厂 `IMVSBlobFindModu.xml` SHA `f1b2f279717dce3ec61c11c41f858bd100359095bcf13672422a3c73efe47f6c`。XML 声明强制输入 `InputImage`，可选 `InputMask`，输出包括 Blob 列表/矩形/角度及二值图和 Blob 图等（字段在原 XML 31–36、88–93、99–104、142–173 行）。此为 schema/装载候选证据，不等于原生算法实现已逆向或已证明 loader 一定绑定这两件文件。
7. Blob 结果内存具有同步/回调两条不同托管路径。`iMVS_6000PlatformSDKCS.SyncPlatformSDKCS.ImvsSdkPFSync.ParseModuleResultToDictionary` 的类型 7 分支先从 `stResModuInfo.pData` 读 `IMVS_PF_BLOBFIND_MODU_INFO`。无 `AsynGetModuleResults` 回调时构造 `BlobFindResult(instance)`，该构造函数为 Blob 单体数组、二值图、Blob 图、轮廓、检测 Region、环形信息分别 `AllocHGlobal+Marshal.Copy`；析构函数释放的是这些新建托管副本。注册了回调时则默认构造并直接赋入原结构指针；写入 Results 后同步调用回调，随即 `Results.Clear()`。因此 callback 分支没有上述 deep-copy 步骤，消费端若需跨回调保存必须先复制；但原生 `pData` 的确切有效期/释放责任仍没有被托管源码证明，不能据此断言 native 在 callback 返回时释放。
8. 普通 VM.Core 结果抽取也有明确 deep-copy 证据：`ModuleResultManager.SetModuleResult` 默认参数为 `Memory_Deep_Copy`；图像深复制路径从 chunk/shared memory 读成 byte[]；轮廓 deep-copy 路径把每个 MatchPoint 复制到 managed List。它可以支撑实现图像/轮廓消费者时选择“深复制”语义，但具体 Blob 结果 getter使用哪条包装路径、native result lease 何时归还，仍需结合原始成员和执行环境确认。

## 关键原始证据路径

| 证据 | 路径 / 成员 | 原始文件 SHA256 |
|---|---|---|
| Blob 托管壳 CIL 元数据 | 安装件 `.../IMVSBlobFindModuCs.dll`；`IMVSBlobFindModuTool.Run` token `0x06000007`；`ModuResult` getter token `0x06000004` | `3106af2e9344a97288553bfbbfa86afd81e2384188b452734f56825f63e0a78d` |
| SDK 执行/查询 | `analysis/decompiled/VM.PlatformSDKCS.Audit/VM.PlatformSDKCS/ModuleManager.cs:266-340,1045-1067`；SDK bridge `docs/architecture-recovery/result-query-ownership.resources/VM.PlatformSDKCS.ServerSDKAPI.decompiled.cs:229-232,1173-1176` | ModuleManager `783a45b1518f713223eca2b5e59291be973552c3e08fef0ea0d4bfccc2fbd922`；ServerSDKAPI `f022d4b4e87d4a076dcf42a79b131a0460ddf673d07603b5ba8d6aca35ef4b14` |
| 可选专用编辑器 | `analysis/decompiled/VMControls.WPF/VMControls.WPF/ProcedureConfigControl.xaml.cs:708-827` | 原 decompile 文件，见工作区审计源；原程序集 SHA 如上 |
| SDK Blob 同步/异步结果路径 | `analysis/decompiled/iMVS-6000PlatformSDKCS.PublicAudit/iMVS_6000PlatformSDKCS.SyncPlatformSDKCS/ImvsSdkPFSync.cs:6317-6324,6555-6583` | `cf996757b649799d87e092af14dcca637010ed2f51cea6d6ceafd16ce74a75a7` |
| SDK Blob deep-copy 与 dispose | 同审计目录 `...SyncPlatformSDKCS/BlobFindResult.cs:33-112` | `080a1a24ac7477d87c385fe1ada5813c71adc6f80570d32adeab5f0d0778a016` |
| VM.Core 结果入口及默认内存模式 | `docs/architecture-recovery/result-query-ownership.resources/VM.Core.VmModule.decompiled.cs:143`、`analysis/decompiled/VM.PlatformSDKCS.Audit/VM.PlatformSDKCS/ModuleResultManager.cs:14-70,252-459,1166-1229` | VmModule `53e2f0f9032c4631b59cf0eb2a00e06d50469d94706e7e370e9cc7e1059c72ce` |
| Blob XML IO schema | 安装件 `.../IMVSBlobFindModu.xml` | `f1b2f279717dce3ec61c11c41f858bd100359095bcf13672422a3c73efe47f6c` |

ILSpy reproducibility: `.tools/ilspycmd.exe --disable-updatecheck -t IMVSBlobFindModuCs.IMVSBlobFindModuTool <原安装 DLL>`；本次保存的定点反编译 `IMVSBlobFindModuTool.decompiled.cs` SHA256 `08af033551889b440ad4cbccf1921c5c1c6144c2547b77f3a39a6fecc6bf1f74`。工具版本及 DLL 哈希另以 `result-query-ownership.provenance.json` 中记录为准。所有 token 仅绑定上述原始程序集 SHA/MVID。

## 仍未证实的断点与最小后续探针

- **Native loader**：没有找到并闭合 `VM.Core/PlatformSDKCS -> native module manager -> IMVSBlobFindModu.dll` 的实际注册、加载、版本校验和错误路径。应从原始 SDK 的模块加载/注册入口追调用和原生 ABI，再确认由文件名、XML 模块名还是 registry 决定绑定。
- **native 结果拥有者**：`QueryModuleOneResult` 的托管代码将 query 指针转结构但此方法中看不到 release 调用；Blob async path 还将 raw pointers 暴露给同步 callback。需要回到 P/Invoke 对应的 native export/调用者，或在受控、同版本 SDK 进程上记录结果到期/释放行为；现阶段不得推断更长/更短生命期。
- **不加载专属编辑器的执行能力**：托管入口与 host fallback 是静态强证；要把“静态可行”提升成运行确认，需一个控制组/实验组同版本原机测试：加载相同 solution/module 与 SDK，控制组加载 Blob `Control.dll`，实验组不加载该程序集；两者对同一输入执行 `Run`、查询同一组结果，并记录成功码、输出值和错误/释放。不要把 generic params editor 缺席和 module-specific control 缺席混为一谈。
- **Algorithm**：本轮没有恢复 `IMVSBlobFindModu.dll` 的算法函数体，也没有比较重建插件输出；本文件不作算法一致性结论。

本轮没有修改产品代码、工具插件工程、原安装文件；没有启动 VM 进程或做人工桌面验收。
