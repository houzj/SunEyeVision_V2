using System.Reflection;
internal static class SafeEntry {
 [STAThread] public static int Main(string[] args) {
  try {
   ReleaseBootstrap.Initialize();
   var assembly=typeof(SafeEntry).Assembly;
   var type=assembly.GetType("Cases")??assembly.GetType("Program")!;
   var method=type.GetMethod(type.Name=="Cases"?"Run":"Main",BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Static)!;
   var value=method.Invoke(null,method.GetParameters().Length==0?null:new object[]{args});
   return value is Task<int> task?task.GetAwaiter().GetResult():(int)value!;
  } catch(Exception error) {Console.Error.WriteLine(error.InnerException??error);return 1;}
 }
}