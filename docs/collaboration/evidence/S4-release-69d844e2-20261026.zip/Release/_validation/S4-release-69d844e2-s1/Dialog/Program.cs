using System.IO;
using System.Reflection;
using System.Runtime.Loader;
using System.Text.Json;
internal static class Cases { public static async Task<int> Run(string[] args) {




var assembly=AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.Combine(Environment.GetEnvironmentVariable("S1_TEST_HELPERS")!,"SunEyeVision.UI.Tests.dll"));
var type=assembly.GetType("SunEyeVision.UI.Tests.SolutionDialogOwnerTests",true)!;
var instance=Activator.CreateInstance(type)!;
var results=new List<object>();
foreach(var entry in new[]{("YesButton","Yes"),("NoButton","No"),("CancelButton","Cancel"),("error","error")}){
 try{
  if(entry.Item1=="error")type.GetMethod("Actual_transition_error_keeps_host_owner_and_reentrant_request_is_rejected")!.Invoke(instance,null);
  else {var method=type.GetMethod("Deferred_closing_keeps_real_owner_and_original_three_button_results")!;method.Invoke(instance,new[]{(object)entry.Item1,Enum.Parse(method.GetParameters()[1].ParameterType,entry.Item2)});}
  results.Add(new{test=entry.Item1,passed=true});
 }catch(Exception ex){results.Add(new{test=entry.Item1,passed=false,error=(ex.InnerException??ex).ToString()});}
}
File.WriteAllText(Path.Combine(Environment.GetEnvironmentVariable("S1_CASE_ROOT")!,"report.json"),JsonSerializer.Serialize(results,new JsonSerializerOptions{WriteIndented=true}));
Console.WriteLine(JsonSerializer.Serialize(results));
return results.All(x=>JsonSerializer.SerializeToElement(x).GetProperty("passed").GetBoolean())?0:1;
} }