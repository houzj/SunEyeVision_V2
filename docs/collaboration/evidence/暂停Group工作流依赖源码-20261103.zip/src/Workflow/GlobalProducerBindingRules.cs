using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using SunEyeVision.Plugin.Contracts;
using SunEyeVision.Plugin.Runtime;
using SunEyeVision.Plugin.SDK.Execution.Parameters;
using SunEyeVision.Plugin.SDK.Models;
using SunEyeVision.Plugin.SDK.Execution.Results;

namespace SunEyeVision.Workflow;

/// <summary>Pure declaration checks for global producers. Does not admit or execute a run,
/// read a result, acquire a resource, or mutate the document.</summary>
public static class GlobalProducerBindingRules
{
    public static bool TryDescribeTarget(string vocabulary, out Port target, out Type clrType, out string reason)
    {
        target=null!;clrType=null!;reason=string.Empty;
        if (!VariableValueDeclarations.TryGetPort(vocabulary, out target))
        { reason = "全局变量尚无资源、组合或几何的正式存储及租约合同，不能建立此生产绑定。"; return false; }
        var declaration = target.Type.Shape == ValueShape.Sequence ? target.Type.Element! : target.Type;
        var scalar = declaration.Scalar switch
        {
            ScalarKind.Boolean => typeof(bool), ScalarKind.Text => typeof(string),
            ScalarKind.Int64 => target.Storage == NumericStorage.Int32 ? typeof(int) : typeof(long),
            ScalarKind.Float64 => target.Storage == NumericStorage.Float32 ? typeof(float) : typeof(double),
            _ => throw new InvalidOperationException("变量声明不是纯值。")
        };
        clrType = target.Type.Shape == ValueShape.Sequence ? scalar.MakeArrayType() : scalar;
        return true;
    }
    public static BindingValidation Validate(Solution solution,ProducerBinding producer,GlobalVariable variable,SunEyeVision.Plugin.Runtime.RuntimeDirectorySnapshot directory)
    {
        ArgumentNullException.ThrowIfNull(solution);ArgumentNullException.ThrowIfNull(directory);
        if(!directory.IsActive || (solution.RuntimeDirectory is {} actual&&!ReferenceEquals(actual,directory)))
            throw new InvalidOperationException("方案与声明查询运行目录代次不一致。");
        return Validate(solution,producer,variable,node=>new OutputBindingChangeService().ReadContract(node,directory));
    }

    // Reconciliation borrows its already captured contracts, including its actual host reader.
    // It must not re-read a mutable provider halfway through building one atomic change plan.
    internal static BindingValidation Validate(Solution solution,ProducerBinding producer,GlobalVariable variable,
        Func<WorkflowNodeBase,ToolSchema?> readContract)
    {
        ArgumentNullException.ThrowIfNull(solution);ArgumentNullException.ThrowIfNull(producer);ArgumentNullException.ThrowIfNull(variable);
        BindingValidation Reject(string message)=>new(BindingCompatibility.Incompatible,message);
        try
        {
            var expression=producer.ReferenceExpression;
            var vocabulary=variable.Type;var variableId=variable.Id;
            var reference=producer.SourceReference;
            if(string.IsNullOrWhiteSpace(reference.ScopeId))return Reject("全局变量生产来源必须声明所属流程作用域。");
            if(reference.Selection is not BindingSelection.AllItems)
                return Reject("全局变量生产绑定当前仅支持声明字段及集合All，不开放未经原件确认的单项或动态索引。");
            if(!TryDescribeTarget(vocabulary,out var target,out var clrType,out var reason))return Reject(reason);
            var flows=solution.Workflows.Where(flow=>flow.Id==reference.ScopeId).ToArray();
            if(flows.Length!=1)return Reject("全局变量生产来源流程已删除或作用域身份不唯一。");
            var sources=flows[0].Nodes.Where(node=>node.Id==reference.NodeId).ToArray();
            if(sources.Length!=1)return Reject("全局变量生产节点已删除或身份不唯一，请重新绑定。");
            var flow=flows[0];var source=sources[0];
            var runtime=source.RuntimeConfiguration;
            bool Current()=>producer.ReferenceExpression==expression&&variable.Type==vocabulary&&variable.Id==variableId
                &&flow.Id==reference.ScopeId&&source.Id==reference.NodeId
                &&solution.Workflows.Count(candidate=>ReferenceEquals(candidate,flow))==1
                &&flow.Nodes.Count(candidate=>ReferenceEquals(candidate,source))==1
                &&ReferenceEquals(source.RuntimeConfiguration,runtime);
            var contract=readContract(source);
            if(!Current())return Reject("读取生产来源声明期间配置或节点归属已改变，请重新选择当前来源。");
            if(contract is null)return new(BindingCompatibility.Unresolved,"生产来源正式输出声明暂不可用，等待校验。");
            var selected=contract.Outputs.Where(output=>output.Id==reference.PortId).ToArray();
            if(selected.Length!=1)return Reject("全局变量原输出身份已删除或不唯一，请重新绑定。");
            var sourceSchema=new ToolSchema(Array.Empty<Port>(),new[]{selected[0]});
            var node=new BindingNodeId(reference.ScopeId,reference.NodeId);
            // This is a design-only scope. No RunIdentity or expected invocation is fabricated.
            var scope=new BindingScopeSnapshot(new(reference.ScopeId,"global-producer:"+variable.Id),Guid.Empty,0,
                new[]{new BindingSource(node,Guid.Empty,sourceSchema,0)},new[]{node},
                Array.Empty<KeyValuePair<BindingNodeId,IReadOnlyList<BindingNodeId>>>());
            var compiled=new ParameterBindingService().CompileBinding(reference,target,scope);
            if(!Current())return Reject("编译生产来源期间配置或节点归属已改变，请重新选择当前来源。");
            return compiled.Plan is null
                ?Reject(compiled.Diagnostic?.Message??"全局变量生产来源声明不符合目标存储类型。")
                :new(compiled.Compatibility,"正式生产来源声明可绑定；运行时仍须当前批次准入与值校验。",clrType);
        }
        catch(Exception failure)when(failure is JsonException or ArgumentException or InvalidOperationException or FormatException or OverflowException)
        {return Reject("全局变量生产绑定无效："+failure.Message);}
    }
}
