using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading;
using SunEyeVision.Plugin.Contracts;
using SunEyeVision.Plugin.SDK.Models;

namespace SunEyeVision.Workflow;

/// <summary>Node editor candidate. A successful commit consumes it; failures keep its edits.</summary>
public sealed class NodeConfigurationEditDraft
{
    internal Guid Owner { get; }
    internal string Signature { get; }
    internal bool Consumed { get; set; }
    public ScopedNodeIdentity Identity { get; }
    public WorkflowNodeBase Node { get; }
    internal RuntimeToolConfiguration? RuntimeValueBaseline {get;}
    internal WorkflowNodeBase FormalInstance {get;}
    internal NodeConfigurationEditDraft(Guid owner, ScopedNodeIdentity identity, WorkflowNodeBase node, string signature, WorkflowNodeBase formalInstance,
        RuntimeToolConfiguration? valueBaseline=null)
    { Owner = owner; Identity = identity; Node = node; Signature = signature;FormalInstance=formalInstance;RuntimeValueBaseline=valueBaseline?.Copy()??node.RuntimeConfiguration?.Copy(); }
}

/// <summary>A private variable/configuration candidate belonging to one document host generation.
/// Value assignment is an explicit command, including assigning the opening value again.</summary>
public sealed class GlobalVariableConfigurationEditDraft
{
    internal sealed record OpeningValue(GlobalVariable Instance, long Revision);
    internal Guid Owner { get; }
    internal bool Consumed { get; set; }
    internal Solution Baseline { get; }
    internal IReadOnlyDictionary<string, OpeningValue> OpeningValues { get; }
    internal Dictionary<string, object?> ExplicitValues { get; } = new(StringComparer.Ordinal);
    public long BaseVersion { get; }
    public Solution Configuration { get; }
    public bool HasValueEdits => ExplicitValues.Count != 0;
    internal Dictionary<string, long> ValueCommandRevisions { get; } = new(StringComparer.Ordinal);

    internal GlobalVariableConfigurationEditDraft(Guid owner, long version, Solution configuration,
        Solution baseline, IReadOnlyDictionary<string, OpeningValue> openingValues)
    { Owner = owner; BaseVersion = version; Configuration = configuration; Baseline = baseline; OpeningValues = openingValues; }

    public void SetValue(string variableId, object? value)
    {
        if (Consumed) throw new InvalidOperationException("变量草稿已提交，请使用新的编辑草稿。");
        var variable = Configuration.GlobalVariables.SingleOrDefault(v => v.Id == variableId)
            ?? throw new InvalidOperationException("要编辑的变量已删除或不属于当前草稿。");
        NodeConfigurationEditHost.ValidateEditableValue(variable.Type, value);
        var owned = GlobalVariable.CopyEditableValue(value);
        // Keep the command separate from the editable display object's array storage.
        ExplicitValues[variableId] = owned;
        ValueCommandRevisions[variableId] = ValueCommandRevisions.GetValueOrDefault(variableId) + 1;
        variable.Value = GlobalVariable.CopyEditableValue(owned);
    }
}

/// <summary>One document's existing configuration publication gateway. Node and variable
/// candidates are composed and validated together before one Store publication.</summary>
public sealed partial class NodeConfigurationEditHost
{
    private readonly Guid _owner = Guid.NewGuid();
    private readonly object _gate = new();
    private readonly Solution _design;
    private readonly List<GlobalVariable> _variableCollection;
    private readonly BindingConfigurationStore _store;
    private readonly Dictionary<ScopedNodeIdentity, WorkflowNodeBase> _nodeInstances;
    // Configuration history can restore a removed variable without replaying an old Value.
    // This is host-local history backing, not a resource owner or a global registry.
    private readonly Dictionary<string, GlobalVariable> _variableInstances;
    private bool _projecting;
    private bool _closed;
    private bool _hasIssuedDraftOrRunAcceptance;
    internal void Close() {lock(_gate)_closed=true;}
    internal void CloseUnusedForInitialPresentation()
    {
        lock(_gate)
        {
            EnsureOpen();
            if(_hasIssuedDraftOrRunAcceptance||_projecting||_store.Capture().Version!=1)
                throw new InvalidOperationException("配置宿主已用于编辑或运行，不能重新准备显示节点。");
            _closed=true;
        }
    }
    private void EnsureOpen()
    {if(_closed)throw new InvalidOperationException("方案配置宿主已经退役。");}
    private SunEyeVision.Plugin.Runtime.RuntimeDirectorySnapshot RequireCurrentDirectory()
    {
        EnsureOpen();
        var directory = _store.Capture().CopyConfiguration().RuntimeDirectory;
        if (directory is null || !directory.IsActive || !ReferenceEquals(_design.RuntimeDirectory, directory) || _design.ExecutionOwner.IsRetired)
            throw new InvalidOperationException("方案已退役或运行目录代次已变更。");
        return directory;
    }
    private readonly List<(GlobalVariable Variable, bool ValueChanged)> _structureNotifications = new();
    // Deterministic acceptance-failure injection only; disabled in production. Tests set
    // this private counter by reflection. It is not an observer/callback under ValueGate.
    private int _acceptanceFailureAfterRawMutation = -1;
    private Exception? _lastRefreshError;
    public Exception? LastRefreshError { get { lock (_gate) return _lastRefreshError; } }

    public NodeConfigurationEditHost(Solution design) : this(design, null) { }
    internal NodeConfigurationEditHost(Solution design, DocumentHistoryCoordinator? history)
    {
        _documentHistory=history;
        _design = design ?? throw new ArgumentNullException(nameof(design));
        _variableCollection = design.GlobalVariables;
        _nodeInstances = Nodes(design);
        CheckVariableDefinitions(design);
        _variableInstances = design.GlobalVariables.ToDictionary(v => v.Id, StringComparer.Ordinal);
        _store = new(design);
        var projection = new Projection();
        try { AcceptProjection(_store.Capture(), null, projection); }
        catch { projection.Restore(this); throw; }
        finally { ReleaseProjection(projection); }
        Emit(projection.Notifications);
    }

    /// <summary>Configuration/dependency history, never the authority for live runtime values.
    /// Save and run capture live values independently with GlobalVariable.CaptureValues.</summary>
    public BindingConfigurationSnapshot Capture() {lock(_gate){EnsureOpen();return _store.Capture();}}
    /// <summary>Frozen names only. Formatting an identity must not capture or inspect runtime variable values.</summary>
    public IReadOnlyDictionary<string,string> GetVariableNames(string solutionId)
    {
        lock(_gate)
        {
            var names=_design.Id==solutionId?_variableCollection.ToDictionary(variable=>variable.Id,variable=>variable.Name,StringComparer.Ordinal):new Dictionary<string,string>(StringComparer.Ordinal);
            return new System.Collections.ObjectModel.ReadOnlyDictionary<string,string>(names);
        }
    }
    /// <summary>Private variable-picker snapshot; captures existing definitions and display values without modifying the document.</summary>
    public (string SolutionId,IReadOnlyList<GlobalVariable> Variables) CaptureVariablesForSelection()
    {lock(_gate){EnsureOpen();if(!ReferenceEquals(_design.GlobalVariables,_variableCollection))throw new InvalidOperationException("变量目录归属已改变。");return(_design.Id,GlobalVariable.CaptureDefinitions(_variableCollection));}}
    public bool CanUndo => !_closed&&(_documentHistory?.CanUndo ?? _store.CanUndo);
    public bool CanRedo => !_closed&&(_documentHistory?.CanRedo ?? _store.CanRedo);
    public bool OwnsNode(string workflowId, WorkflowNodeBase node)
    { lock (_gate) return !_closed&&_design.Workflows.Any(w => w.Id == workflowId && w.Nodes.Any(n => ReferenceEquals(n, node))); }

    public void SynchronizeStructure()
    {
        try { lock (_gate) EnsureBaseline(); }
        finally { FlushStructureNotifications(); }
    }
    public bool HasPublishedNodeChanged(NodeConfigurationEditDraft editor)
    {
        lock (_gate) return !IsCurrentNodeInstance(editor) || NodeEditSignature(Find(_store.Capture().CopyConfiguration(), editor.Identity)) != editor.Signature;
    }

    public NodeConfigurationEditDraft BeginEdit(string workflowId, string nodeId)
    {
        try
        {

            lock (_gate)
            {
                EnsureBaseline();
                _hasIssuedDraftOrRunAcceptance=true;
                var identity = new ScopedNodeIdentity(workflowId, nodeId);
                var node = Find(_store.Capture().CopyConfiguration(), identity);
                return new(_owner, identity, node, NodeEditSignature(node),_nodeInstances[identity]);
            }
        }
        finally { FlushStructureNotifications(); }
    }

    public GlobalVariableConfigurationEditDraft BeginVariableEdit()
    {
        try
        {

            lock (_gate)
            {
                EnsureBaseline();
                _hasIssuedDraftOrRunAcceptance=true;
                var published = _store.Capture();
                var configuration = published.CopyConfiguration();
                var captures = GlobalVariable.CaptureValues(_variableCollection);
                var openings = new Dictionary<string, GlobalVariableConfigurationEditDraft.OpeningValue>(StringComparer.Ordinal);
                foreach (var variable in _variableCollection)
                {
                    var captured = captures[variable.Id];
                    openings.Add(variable.Id, new(variable, captured.Revision));
                    // Pure scalar/sequence values follow their frozen declaration even when
                    // the existing manager has no array text editor. Native values stay borrowed.
                    if (GlobalVariable.IsPureValueDeclaration(variable.Type))
                        configuration.GlobalVariables.Single(v => v.Id == variable.Id).Value = GlobalVariable.CopyEditableValue(captured.Value);
                }
                return new(_owner, published.Version, configuration, BindingConfigurationStore.Copy(configuration), openings);
            }
        }
        finally { FlushStructureNotifications(); }
    }

    public bool HasPendingChanges(NodeConfigurationEditDraft editor) => NodeEditSignature(editor.Node) != editor.Signature
        ||editor.Node.RuntimeConfiguration?.HasCurrentValueChangesFrom(editor.RuntimeValueBaseline)==true;
    public bool HasPendingChanges(GlobalVariableConfigurationEditDraft editor)
        => editor.HasValueEdits || ShapeSignature(editor.Configuration) != ShapeSignature(editor.Baseline);

    public static bool SamePendingEdits(GlobalVariableConfigurationEditDraft left, GlobalVariableConfigurationEditDraft right)
        => ShapeSignature(left.Configuration) == ShapeSignature(right.Configuration) &&
            left.ValueCommandRevisions.Count == right.ValueCommandRevisions.Count &&
            left.ValueCommandRevisions.All(p => right.ValueCommandRevisions.TryGetValue(p.Key, out var revision) && revision == p.Value) &&
            left.ExplicitValues.All(p => right.ExplicitValues.TryGetValue(p.Key, out var value) && SameEditableValue(p.Value, value));
    public GlobalVariableConfigurationEditDraft RebaseAcceptedDraft(GlobalVariableConfigurationEditDraft edited,
        GlobalVariableConfigurationEditDraft prepared)
    {
        try
        {

            lock (_gate)
            {
                if (edited.Owner != _owner || prepared.Owner != _owner)
                    throw new InvalidOperationException("变量草稿不属于当前文档。");
                var fresh = BeginVariableEdit();
                var latestNodes = Nodes(fresh.Configuration);
                var preparedNodes = Nodes(prepared.Configuration);
                foreach (var pair in Nodes(edited.Configuration))
                    if (preparedNodes.TryGetValue(pair.Key, out var old) && ParametersSignature(pair.Value) == ParametersSignature(old))
                        SetParameters(pair.Value, latestNodes[pair.Key]);
                var result = new GlobalVariableConfigurationEditDraft(_owner, fresh.BaseVersion,
                    edited.Configuration, fresh.Baseline, fresh.OpeningValues);
                foreach (var variable in edited.Configuration.GlobalVariables)
                {
                    var newerCommand = edited.ValueCommandRevisions.TryGetValue(variable.Id, out var revision) &&
                        (!prepared.ValueCommandRevisions.TryGetValue(variable.Id, out var acceptedRevision) || revision != acceptedRevision);
                    if (newerCommand && edited.ExplicitValues.TryGetValue(variable.Id, out var value))
                    {
                        result.ExplicitValues[variable.Id] = GlobalVariable.CopyEditableValue(value);
                        result.ValueCommandRevisions[variable.Id] = revision;
                    }
                    else if (fresh.Configuration.GlobalVariables.SingleOrDefault(v => v.Id == variable.Id) is { } current && GlobalVariable.IsPureValueDeclaration(variable.Type))
                        variable.Value = GlobalVariable.CopyEditableValue(current.Value);
                }
                edited.Consumed = true;
                return result;
            }
        }
        finally { FlushStructureNotifications(); }
    }

    public static bool SamePendingEdits(NodeConfigurationEditDraft left, NodeConfigurationEditDraft right)
        => left.Identity == right.Identity && ReferenceEquals(left.FormalInstance,right.FormalInstance) && NodeEditSignature(left.Node) == NodeEditSignature(right.Node)
            &&left.Node.RuntimeConfiguration?.CurrentValuesIdentity==right.Node.RuntimeConfiguration?.CurrentValuesIdentity;
    public NodeConfigurationEditDraft RebaseAcceptedDraft(NodeConfigurationEditDraft editor)
    {
        try
        {

            lock (_gate)
            {
                if (editor.Owner != _owner) throw new InvalidOperationException("草稿不属于当前文档。");
                EnsureBaseline();
                RequireCurrentNodeInstance(editor);
                var accepted = Find(_store.Capture().CopyConfiguration(), editor.Identity);
                editor.Consumed = true;
                // Keep the same private object so raw view input and newer edits are not rebound away.
                return new(_owner, editor.Identity, editor.Node, NodeEditSignature(accepted),editor.FormalInstance,accepted.RuntimeConfiguration);
            }
        }
        finally { FlushStructureNotifications(); }
    }

    /// <summary>Copy a proposal while retaining its original owner/baseline for conflict checks.</summary>
    public NodeConfigurationEditDraft Freeze(NodeConfigurationEditDraft editor)
    {
        lock (_gate)
        {
            if (editor.Owner != _owner || editor.Consumed)
                throw new InvalidOperationException("节点草稿已接受或不属于当前文档。");
            RequireCurrentNodeInstance(editor);
            var directory = RequireCurrentDirectory();
            var source = editor.Node;
            RuntimeNodeAdmission.Require(directory, source);
            var copy = new WorkflowNodeBase(source.Id, source.Name, source.DispName, source.ToolType)
            {
                SubroutineId = source.SubroutineId, GlobalIndex = source.GlobalIndex, LocalIndex = source.LocalIndex,
                IsEnabled = source.IsEnabled, PositionX = source.PositionX, PositionY = source.PositionY,
                Width = source.Width, Height = source.Height,
                AdditionalData = source.AdditionalData?.ToDictionary(entry => entry.Key, entry => entry.Value.Clone()),
                RuntimeConfiguration = source.RuntimeConfiguration!.Copy(),
                SelectedDisplayReference = source.SelectedDisplayReference
            };
            return new(_owner, editor.Identity, copy, editor.Signature,editor.FormalInstance,editor.RuntimeValueBaseline);
        }
    }
    public GlobalVariableConfigurationEditDraft Freeze(GlobalVariableConfigurationEditDraft editor)
    {
        lock (_gate)
        {
            EnsureOpen();
            if (editor.Owner != _owner || editor.Consumed)
                throw new InvalidOperationException("变量草稿已接受或不属于当前文档。");
            var directory = RequireCurrentDirectory();
            if (!ReferenceEquals(editor.Configuration.RuntimeDirectory, directory) || !ReferenceEquals(editor.Baseline.RuntimeDirectory, directory))
                throw new InvalidOperationException("变量草稿运行目录代次已变更。");
            var copy = new GlobalVariableConfigurationEditDraft(_owner, editor.BaseVersion,
                BindingConfigurationStore.Copy(editor.Configuration), BindingConfigurationStore.Copy(editor.Baseline),
                new Dictionary<string, GlobalVariableConfigurationEditDraft.OpeningValue>(editor.OpeningValues));
            foreach (var entry in editor.ExplicitValues)
                copy.ExplicitValues.Add(entry.Key, GlobalVariable.CopyEditableValue(entry.Value));
            foreach (var entry in editor.ValueCommandRevisions) copy.ValueCommandRevisions.Add(entry.Key, entry.Value);
            return copy;
        }
    }

    public void Validate(NodeConfigurationEditDraft editor)
    { ArgumentNullException.ThrowIfNull(editor); ValidateBatch(new[] { editor }, null); }
    /// <summary>Validate proposed Runtime fields against current declarations, known settings
    /// and the complete candidate dependency graph, without requiring unfinished input groups.
    /// This does not publish a candidate or replace the complete validation at capture/commit.</summary>
    public void ValidateRuntimeFieldProposals(NodeConfigurationEditDraft editor,IReadOnlyDictionary<string,ParameterSetting> changes)
    {
        ArgumentNullException.ThrowIfNull(editor);ArgumentNullException.ThrowIfNull(changes);
        try
        {
            lock(_gate)
            {
                var batch=Compose(new[]{editor},null,null);var version=_store.Capture().Version;
                var flow=batch.Draft.Configuration.Workflows.Single(workflow=>workflow.Id==editor.Identity.WorkflowId);
                var node=Find(batch.Draft.Configuration,editor.Identity);
                var runtime=node.RuntimeConfiguration??throw new InvalidOperationException("节点没有Runtime配置。");
                _=runtime.Fields.Apply(changes); // Freeze every proposed value against its actual declaration.
                var proposed=runtime.WithFieldSettings(changes);node.RuntimeConfiguration=proposed;
                RuntimeDisplayBindings.Validate(flow,node,proposed,batch.Draft.Configuration.RuntimeDirectory??throw new InvalidOperationException("方案缺少已准入目录。"),changes.Keys.ToHashSet(StringComparer.Ordinal));
                var settingsErrors=proposed.ValidateSettings();
                if(settingsErrors.Count!=0)throw new ArgumentException(settingsErrors[0].Message);
                foreach(var (id,setting) in proposed.CaptureExecutionFields())
                {
                    if(setting is VariableSetting variable)
                    {WorkflowBindingContext.ValidateVariable(batch.Draft.Configuration,flow,node,id,variable);continue;}
                    if(setting is not ReferenceSetting reference)continue;
                    if(reference.RebindingReason is {Length:>0} reason)throw new ArgumentException(reason);
                    var result=WorkflowBindingContext.ValidateTyped(flow,node,id,reference,flow.Id,batch.Draft.Configuration.RuntimeDirectory??throw new InvalidOperationException("方案缺少已准入目录。"),batch.Draft.Configuration);
                    if(result.State is BindingCompatibility.Incompatible or BindingCompatibility.Unresolved)
                        throw new ArgumentException(result.Reason);
                }
                // No readiness filtering: every configured active edge, including a proposed
                // variable producer or dynamic index, must participate in cycle detection.
                _=SolutionExecutionDependencyGraph.Compile(batch.Draft.Configuration,checkReadiness:false);
                EnsureBaseline();
                if(_store.Capture().Version!=version)throw new InvalidOperationException("来源声明或方案已变化，请重试。");
            }
        }
        finally{FlushStructureNotifications();}
    }
    public BindingConfigurationPublication Commit(NodeConfigurationEditDraft editor)
    { ArgumentNullException.ThrowIfNull(editor); return CommitBatch(new[] { editor }, null); }

    public void ValidateBatch(IReadOnlyList<NodeConfigurationEditDraft> editors, GlobalVariableConfigurationEditDraft? variables, IReadOnlyList<RootWorkflowConfigurationEditDraft>? roots = null)
    {
        try
        {

            ArgumentNullException.ThrowIfNull(editors);
            lock (_gate)
            {
                var prepared = Compose(editors, variables, roots);
                _store.Validate(prepared.Draft, c => ValidateCandidate(c, prepared.Participants, variables != null));
                lock (GlobalVariable.ValueGate)
                {
                    CheckValueWrites(variables);
                    CheckValueTypes(prepared.Draft.Configuration, variables);
                }
            }
        }
        finally { FlushStructureNotifications(); }
    }

    public BindingConfigurationPublication CommitBatch(IReadOnlyList<NodeConfigurationEditDraft> editors,
        GlobalVariableConfigurationEditDraft? variables, IReadOnlyList<RootWorkflowConfigurationEditDraft>? roots = null)
        => CommitWithDocumentHistory(editors,variables,roots);

    private BindingConfigurationPublication CommitBatchCore(IReadOnlyList<NodeConfigurationEditDraft> editors,
        GlobalVariableConfigurationEditDraft? variables, IReadOnlyList<RootWorkflowConfigurationEditDraft>? roots,
        bool recordHistory)
    {
        try
        {

            ArgumentNullException.ThrowIfNull(editors);
            BindingConfigurationPublication publication;
            List<(GlobalVariable Variable, bool ValueChanged)> notifications;
            lock (_gate)
            {
                var prepared = Compose(editors, variables, roots);
                var projection = new Projection();
                try
                {
                    var valueOnly = (variables?.HasValueEdits == true||editors.Any(editor=>
                        editor.Node.RuntimeConfiguration?.HasCurrentValueChangesFrom(editor.RuntimeValueBaseline)==true)) &&
                        ShapeSignature(prepared.Draft.Configuration) == ShapeSignature(_store.Capture().CopyConfiguration());
                    publication = valueOnly
                        ? _store.AcceptRuntimeValues(prepared.Draft,
                            snapshot => AcceptProjection(snapshot, variables, projection),
                            c => ValidateCandidate(c, prepared.Participants, variables != null))
                        : _store.Publish(prepared.Draft,
                            snapshot => AcceptProjection(snapshot, variables, projection),
                            forcePublication: variables?.HasValueEdits == true,
                            validate: c => ValidateCandidate(c, prepared.Participants, variables != null),recordHistory:recordHistory);
                    foreach (var editor in editors) editor.Consumed = true;
                    if (variables != null) variables.Consumed = true;
                    foreach(var root in roots??Array.Empty<RootWorkflowConfigurationEditDraft>())root.Consumed=true;
                    notifications = projection.Notifications;
                }
                catch { projection.Restore(this); throw; }
                finally { ReleaseProjection(projection); }
            }
            Emit(notifications);
            return publication;
        }
        finally { FlushStructureNotifications(); }
    }

    public BindingConfigurationSnapshot Undo() {lock(_gate)EnsureOpen();return RestoreDocumentHistory(undo:true);}
    public BindingConfigurationSnapshot Redo() {lock(_gate)EnsureOpen();return RestoreDocumentHistory(undo:false);}
    private BindingConfigurationSnapshot RestoreHistory(bool undo)
    {
        try
        {

            BindingConfigurationSnapshot snapshot;
            List<(GlobalVariable Variable, bool ValueChanged)> notifications;
            lock (_gate)
            {
                EnsureBaseline();
                var projection = new Projection();
                try
                {
                    var version = _store.Capture().Version;
                    // No explicit value write set is replayed by configuration history.
                    snapshot = undo ? _store.Undo(version, s => AcceptProjection(s, null, projection))
                        : _store.Redo(version, s => AcceptProjection(s, null, projection));
                    notifications = projection.Notifications;
                }
                catch { projection.Restore(this); throw; }
                finally { ReleaseProjection(projection); }
            }
            Emit(notifications);
            return snapshot;
        }
        finally { FlushStructureNotifications(); }
    }

    private sealed record PreparedBatch(BindingConfigurationDraft Draft, HashSet<ScopedNodeIdentity> Participants);
    private PreparedBatch Compose(IReadOnlyList<NodeConfigurationEditDraft> editors, GlobalVariableConfigurationEditDraft? variables, IReadOnlyList<RootWorkflowConfigurationEditDraft>? roots)
    {
        EnsureBaseline();
        var draft = _store.BeginEdit();
        var baseline = draft.Configuration;
        var byId = new Dictionary<ScopedNodeIdentity, NodeConfigurationEditDraft>();
        foreach (var editor in editors)
        {
            if (editor == null || editor.Owner != _owner || editor.Consumed)
                throw new InvalidOperationException("编辑草稿已提交或不属于当前方案。");
            RequireCurrentNodeInstance(editor);
            if (!byId.TryAdd(editor.Identity, editor)) throw new InvalidOperationException("同一节点有重复的编辑参与者。");
            var current = Find(baseline, editor.Identity);
            if (NodeEditSignature(current) != editor.Signature)
                throw new InvalidOperationException("当前节点正式配置已变化，草稿已保留，请重新确认后编辑。");
            if (editor.Node.Id != current.Id || editor.Node.ToolType != current.ToolType)
                throw new InvalidOperationException("参数编辑不能更换节点身份或工具类型。");
        }
        var participants = byId.Keys.ToHashSet();
        if (variables != null)
        {
            if (variables.Owner != _owner || variables.Consumed ||
                variables.BaseVersion != _store.Capture().Version &&
                !variables.Baseline.GlobalVariables.Select(VariableConfigurationSignature).SequenceEqual(
                    baseline.GlobalVariables.Select(VariableConfigurationSignature)))
                throw new InvalidOperationException("变量草稿不属于当前方案或配置版本已过期，草稿已保留。");
            if (VariableDraftStructure(variables.Configuration) != VariableDraftStructure(variables.Baseline))
                throw new InvalidOperationException("变量编辑不能改变方案、节点身份、画布或拓扑。");
            CheckVariableDefinitions(variables.Configuration);
            var variableNodes = Nodes(variables.Configuration);
            var openingNodes = Nodes(variables.Baseline);
            foreach (var pair in variableNodes)
            {
                var changed = ParametersSignature(pair.Value) != ParametersSignature(openingNodes[pair.Key]);
                if (!changed) continue;
                var publishedParameters = ParametersSignature(Find(baseline, pair.Key));
                if (publishedParameters != ParametersSignature(openingNodes[pair.Key]) && publishedParameters != ParametersSignature(pair.Value))
                    throw new InvalidOperationException("变量编辑涉及的节点配置已被另一个范围修改，不能覆盖；草稿保留。");
                participants.Add(pair.Key);
                if (byId.TryGetValue(pair.Key, out var editor))
                {
                    var nodeChanged = ParametersSignature(editor.Node) != ParametersSignature(Find(baseline, pair.Key));
                    if (nodeChanged && ParametersSignature(editor.Node) != ParametersSignature(pair.Value))
                        throw new InvalidOperationException("变量绑定和节点草稿同时修改了同一节点参数/绑定，请保留草稿并消除重叠后重试。");
                    byId.Remove(pair.Key);
                }
                SetParameters(Find(draft.Configuration, pair.Key), pair.Value);
            }
            var openingVariables = variables.Baseline.GlobalVariables.ToDictionary(v => v.Id, StringComparer.Ordinal);
            var historicalValues = baseline.GlobalVariables.ToDictionary(v => v.Id, v => v.Value, StringComparer.Ordinal);
            draft.Configuration.GlobalVariables.Clear();
            foreach (var variable in variables.Configuration.GlobalVariables)
            {
                if (openingVariables.TryGetValue(variable.Id, out var openingVariable))
                {
                    if (GlobalVariable.IsPureValueDeclaration(variable.Type) && !variables.ExplicitValues.ContainsKey(variable.Id) && !SameEditableValue(variable.Value, openingVariable.Value))
                        throw new InvalidOperationException("当前值编辑必须通过变量草稿 SetValue 显式提交。");
                }
                else if (_variableInstances.ContainsKey(variable.Id))
                    throw new InvalidOperationException("新变量不能复用本编辑历史中已有的稳定Id。");
                var copy = CopyVariable(variable);
                if (variables.ExplicitValues.TryGetValue(variable.Id, out var value))
                {
                    ValidateEditableValue(copy.Type, value);
                    if (!SameEditableValue(variable.Value, value))
                        throw new InvalidOperationException("变量当前值在 SetValue 之后又被直接修改，草稿已保留。");
                    copy.Value = GlobalVariable.CopyEditableValue(value);
                }
                else if (historicalValues.TryGetValue(variable.Id, out var historicalValue))
                    copy.Value = GlobalVariable.CopyEditableValue(historicalValue);
                // Only explicit commands change an existing live value. Store values remain
                // a copied configuration payload and are never fed back by Apply/Undo/Redo.
                draft.Configuration.GlobalVariables.Add(copy);
            }
        }
        foreach (var editor in byId.Values)
        {
            var target=Find(draft.Configuration,editor.Identity);
            var live=target.RuntimeConfiguration;
            SetParameters(target,editor.Node);
            if(target.RuntimeConfiguration is {} candidate&&live is not null)
                target.RuntimeConfiguration=candidate.MergeCurrentValues(live,editor.RuntimeValueBaseline);
        }
        ComposeRoots(draft.Configuration,roots);
        // Runtime settings validate editable structure; invocation readiness is separate.
        return new(draft, participants);
    }

    private static void ValidateCandidate(Solution candidate, HashSet<ScopedNodeIdentity> participants, bool validateAllBindings)
    {
        CheckVariableDefinitions(candidate);
        foreach (var flow in candidate.Workflows)
        {
            var issues = OutputBindingChangeService.GetExecutionInputIssues(flow, candidate.RuntimeDirectory??throw new InvalidOperationException("方案缺少已准入目录。"), flow.Id);
            if (validateAllBindings && issues.Values.SelectMany(i => i).FirstOrDefault() is { } batchIssue)
                throw new InvalidOperationException(batchIssue.Message);
            foreach(var node in flow.Nodes.Where(node=>node.RuntimeConfiguration is not null&&(validateAllBindings||participants.Contains(new(flow.Id,node.Id)))))
                foreach(var (fieldId,setting) in node.RuntimeConfiguration!.Fields.Capture())
                {
                    if(setting is VariableSetting variable)WorkflowBindingContext.ValidateVariable(candidate,flow,node,fieldId,variable);
                    else if(setting is ReferenceSetting reference&&BindingRelationCatalog.IndexVariables(reference.Reference.Selection).Any())
                    {
                        var validation=WorkflowBindingContext.ValidateTyped(flow,node,fieldId,reference,flow.Id,candidate.RuntimeDirectory??throw new InvalidOperationException("方案缺少已准入目录。"),candidate);
                        if(validation.State is BindingCompatibility.Incompatible or BindingCompatibility.Unresolved)throw new InvalidOperationException(validation.Reason);
                    }
                }
            foreach (var node in flow.Nodes.Where(n => participants.Contains(new(flow.Id, n.Id))))
            {
                if (node.RuntimeConfiguration is { } sourceRuntime && sourceRuntime.ToolId != node.ToolType)
                    throw new InvalidOperationException("Runtime配置与节点工具身份不符。");
                if (node.RuntimeConfiguration is { } runtime)
                {
                    var diagnostics = runtime.Validate();
                    if (diagnostics.Count != 0) throw new InvalidOperationException(diagnostics[0].Message);
                }
                else
                {
                    throw new InvalidOperationException("节点缺少已准入 Runtime 配置。");
                }
                if (issues.TryGetValue(node.Id, out var inputIssues) && inputIssues.Count > 0)
                    throw new InvalidOperationException(inputIssues[0].Message);
            }
        }
    }

    private static void CheckVariableDefinitions(Solution configuration)
    {
        var ids = new HashSet<string>(StringComparer.Ordinal);
        var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var variable in configuration.GlobalVariables)
        {
            if (string.IsNullOrWhiteSpace(variable.Id) || !ids.Add(variable.Id))
                throw new InvalidOperationException("变量Id不能为空或重复。");
            var result = variable.Validate();
            if (!result.IsValid) throw new InvalidOperationException(result.Errors[0]);
            if (!names.Add(variable.Name)) throw new InvalidOperationException("变量名称不能重复（不区分大小写）。");
        }
    }

    internal static void ValidateEditableValue(string type, object? value)
    {
        var valid = type switch
        {
            "Integer" => value is int or long or int[] or long[],
            "Double" => value is float f ? float.IsFinite(f) : value is double d ? double.IsFinite(d)
                : value is float[] fs ? fs.All(float.IsFinite) : value is double[] ds && ds.All(double.IsFinite),
            "String" => value is string or string[],
            "Boolean" => value is bool or bool[],
            "Integer[]" => value is long[],
            "Double[]" => value is double[] sequence && sequence.All(double.IsFinite),
            "String[]" => value is string[] texts && texts.All(text=>text is not null),
            "Boolean[]" => value is bool[],
            _ => false
        };
        if (!valid) throw new InvalidOperationException("当前值与变量类型不匹配，或该类型不支持文本值编辑。");
    }

    private void CheckValueWrites(GlobalVariableConfigurationEditDraft? variables)
    {
        if (variables == null) return;
        foreach (var pair in variables.ExplicitValues)
        {
            if (variables.OpeningValues.TryGetValue(pair.Key, out var opening))
            {
                var live = _variableCollection.SingleOrDefault(v => v.Id == pair.Key);
                if (live == null || !ReferenceEquals(live, opening.Instance) || live.CaptureValueRaw().Revision != opening.Revision)
                    throw new InvalidOperationException("变量当前值已在编辑期间更新，整批未发布；草稿已保留，请重新确认当前值。");
                _ = checked(opening.Revision + 1);
            }
            else if (_variableCollection.Any(v => v.Id == pair.Key))
                throw new InvalidOperationException("新变量Id已被正式变量占用。");
        }
    }

    private void CheckValueTypes(Solution candidate, GlobalVariableConfigurationEditDraft? variables)
    {
        foreach (var next in candidate.GlobalVariables)
        {
            if (variables != null && variables.ExplicitValues.TryGetValue(next.Id, out var explicitValue))
            { ValidateEditableValue(next.Type, explicitValue); continue; }
            var known = _variableInstances.TryGetValue(next.Id, out var existing);
            var value = known ? existing!.CaptureValueRaw().Value : next.CaptureValueRaw().Value;
            if (known && existing!.Type == next.Type) continue;
            if (GlobalVariable.IsPureValueDeclaration(next.Type))
            {
                // A declared sequence may have no design value; a producer fills the batch
                // slot. Do not turn that absence into an empty or single-item sequence.
                if(value is null&&GlobalProducerBindingRules.TryDescribeTarget(next.Type,out var declaration,out _,out _)
                    &&declaration.Type.Shape==ValueShape.Sequence)continue;
                ValidateEditableValue(next.Type, value);
            }
            else if (value != null && SdkTypeVocabulary.ToTypeVocabulary(value.GetType()) != next.Type)
                throw new InvalidOperationException("变量新类型与当前运行值不兼容，请显式编辑合法值后再提交。");
        }
    }

    private void RawMutationCompleted()
    {
        if (_acceptanceFailureAfterRawMutation < 0) return;
        if (--_acceptanceFailureAfterRawMutation <= 0)
            throw new InvalidOperationException("Injected configuration acceptance failure after raw mutation.");
    }
    private sealed class Projection
    {
        internal bool HoldsValueGate;
        internal bool Applied;
        internal readonly List<(Workflow Root,RootWorkflowConfiguration Before,RootWorkflowConfiguration After)> Roots=new();
        internal List<GlobalVariable>? PreviousOrder;
        internal readonly List<(WorkflowNodeBase Node, RuntimeToolConfiguration? Runtime)> Nodes = new();
        internal readonly List<(GlobalVariable Variable, GlobalVariable.ConfigurationState Configuration, GlobalVariable.ValueState Value)> Variables = new();
        internal readonly List<string> AddedInstances = new();
        internal readonly List<(GlobalVariable Variable, bool ValueChanged)> Notifications = new();

        internal void Restore(NodeConfigurationEditHost host)
        {
            if (!Applied) return;
            foreach(var root in Roots)root.Root.ApplyRootConfigurationRaw(root.Before);
            foreach (var node in Nodes) node.Node.RuntimeConfiguration = node.Runtime;
            foreach (var variable in Variables)
            {
                variable.Variable.ApplyConfigurationRaw(variable.Configuration);
                variable.Variable.ApplyValueRaw(variable.Value);
            }
            if (PreviousOrder != null) { host._variableCollection.Clear(); host._variableCollection.AddRange(PreviousOrder); }
            foreach (var id in AddedInstances) host._variableInstances.Remove(id);
            Applied = false;
        }
    }

    private void AcceptProjection(BindingConfigurationSnapshot snapshot, GlobalVariableConfigurationEditDraft? variables, Projection projection)
    {
        // All cloning/serialization and allocation of the candidate happen before ValueGate.
        var candidate = snapshot.CopyConfiguration();
        var nextNodes = Nodes(candidate);
        if (!_nodeInstances.Keys.ToHashSet().SetEquals(nextNodes.Keys))
            throw new InvalidOperationException("配置编辑不能增删节点。");
        foreach(var next in candidate.Workflows.Where(w=>!w.IsSubroutine))
        {var root=_design.Workflows.Single(w=>w.Id==next.Id&&!w.IsSubroutine);if(RootSignature(root.RootConfiguration)!=RootSignature(next.RootConfiguration))projection.Roots.Add((root,root.RootConfiguration,next.RootConfiguration));}
        var plans = candidate.GlobalVariables.Select(v => (Next: v,
            Target: _variableInstances.TryGetValue(v.Id, out var existing) ? existing : v,
            State: v.CaptureConfiguration())).ToArray();
        var nextOrder = plans.Select(p => p.Target).ToArray();
        var valueWrites = variables?.ExplicitValues.ToDictionary(p => p.Key,
            p => GlobalVariable.CopyEditableValue(p.Value), StringComparer.Ordinal);
        _variableInstances.EnsureCapacity(checked(_variableInstances.Count + plans.Count(p => !_variableInstances.ContainsKey(p.Next.Id))));
        projection.Variables.EnsureCapacity(plans.Length);
        projection.Notifications.EnsureCapacity(plans.Length);
        projection.AddedInstances.EnsureCapacity(plans.Length);
        _variableCollection.EnsureCapacity(Math.Max(_variableCollection.Count, nextOrder.Length));
        projection.PreviousOrder = _variableCollection.ToList();
        foreach (var pair in nextNodes)
        {
            var target = _nodeInstances[pair.Key];
            if (ParametersSignature(target) != ParametersSignature(pair.Value)
                ||target.RuntimeConfiguration?.CurrentValuesIdentity!=pair.Value.RuntimeConfiguration?.CurrentValuesIdentity)
                projection.Nodes.Add((target, target.RuntimeConfiguration));
        }
        var configChanged = plans.ToDictionary(p => p.Next.Id,
            p => VariableConfigurationSignature(p.Target) != VariableConfigurationSignature(p.Next), StringComparer.Ordinal);
        Monitor.Enter(GlobalVariable.ValueGate);
        projection.HoldsValueGate = true;
        _projecting = true;
        CheckValueWrites(variables);
        CheckValueTypes(candidate, variables);
        foreach (var plan in plans)
        {
            var current = plan.Target.CaptureValueRaw();
            if (valueWrites?.ContainsKey(plan.Next.Id) == true) _ = checked(current.Revision + 1);
            projection.Variables.Add((plan.Target, plan.Target.CaptureConfiguration(), current));
        }
        // Everything below is raw model/list assignment. It invokes no virtual method,
        // property setter, logger, serializer, WPF object or subscription callback.
        projection.Applied = true;
        foreach(var root in projection.Roots){root.Root.ApplyRootConfigurationRaw(root.After);RawMutationCompleted();}
        foreach (var pair in nextNodes)
            if (projection.Nodes.Any(p => ReferenceEquals(p.Node, _nodeInstances[pair.Key])))
            {


                _nodeInstances[pair.Key].RuntimeConfiguration = pair.Value.RuntimeConfiguration;
                RawMutationCompleted();
            }
        foreach (var plan in plans)
        {
            if (!_variableInstances.ContainsKey(plan.Next.Id))
            { projection.AddedInstances.Add(plan.Next.Id); _variableInstances.Add(plan.Next.Id, plan.Target); }
            if (configChanged[plan.Next.Id])
            { plan.Target.ApplyConfigurationRaw(plan.State with { ModifiedTime = plan.Target.ModifiedTime }); RawMutationCompleted(); }
            var valueChanged = valueWrites?.ContainsKey(plan.Next.Id) == true;
            if (valueChanged)
            {
                var previous = plan.Target.CaptureValueRaw();
                plan.Target.ApplyValueRaw(new(valueWrites![plan.Next.Id], checked(previous.Revision + 1)));
                RawMutationCompleted();
            }
            if (configChanged[plan.Next.Id] || valueChanged) projection.Notifications.Add((plan.Target, valueChanged));
        }
        _variableCollection.Clear(); _variableCollection.AddRange(nextOrder);
        RawMutationCompleted();
        // Keep ValueGate held until Store.Publish/Undo/Redo has completed its generation
        // assignment. The caller releases it in finally, then releases Host._gate.
    }

    private void ReleaseProjection(Projection projection)
    {
        if(projection.Applied)foreach(var root in projection.Roots)_rootNotifications.Add(root.Root);
        _projecting = false;
        if (projection.HoldsValueGate) { projection.HoldsValueGate = false; Monitor.Exit(GlobalVariable.ValueGate); }
    }

    private void Emit(List<(GlobalVariable Variable, bool ValueChanged)> notifications)
    {
        var errors = new List<Exception>();
        foreach (var notification in notifications)
            notification.Variable.EmitConfigurationNotifications(notification.ValueChanged, errors);
        lock (_gate) _lastRefreshError = errors.Count == 0 ? null : new AggregateException("配置已发布，但部分视图通知失败。", errors);
    }

    // A stable Id identifies a document slot, not a replacement node instance. An old
    // editor cannot attach to a recreated node merely because its values match.
    private bool IsCurrentNodeInstance(NodeConfigurationEditDraft editor)
        =>!_closed&&editor.Owner==_owner&&_nodeInstances.TryGetValue(editor.Identity,out var current)
            &&ReferenceEquals(current,editor.FormalInstance)
            &&_design.Workflows.Any(flow=>flow.Id==editor.Identity.WorkflowId
                &&flow.Nodes.Any(node=>ReferenceEquals(node,editor.FormalInstance)));
    private void RequireCurrentNodeInstance(NodeConfigurationEditDraft editor)
    {
        if(!IsCurrentNodeInstance(editor))throw new InvalidOperationException("节点已删除或正式实例已替换，请重新打开参数编辑。");
    }

    private void EnsureBaseline()
    {
        EnsureOpen();
        if (_projecting) throw new InvalidOperationException("配置投影过程中不能重入编辑或恢复。");
        if (!ReferenceEquals(_design.GlobalVariables, _variableCollection)) throw new InvalidOperationException("正式变量集合已被替换。");
        if (_variableCollection.Any(v => !_variableInstances.TryGetValue(v.Id, out var original) || !ReferenceEquals(original, v)))
            throw new InvalidOperationException("正式变量实例已在编辑事务之外变化。");
        var currentNodes = Nodes(_design);
        var formal = _store.Capture().CopyConfiguration();
        var publishedNodes = Nodes(formal);
        var sameInstances = currentNodes.Count == _nodeInstances.Count &&
            currentNodes.All(p => _nodeInstances.TryGetValue(p.Key, out var old) && ReferenceEquals(old, p.Value));
        if (!sameInstances || StructureSignature(formal) != StructureSignature(_design))
        {
            // Canvas edits are already explicit formal actions. They may change structure/metadata,
            // but must not smuggle live parameter or variable-definition writes into this gateway.
            foreach (var pair in currentNodes)
                if (_nodeInstances.TryGetValue(pair.Key, out var original) && ReferenceEquals(original, pair.Value) &&
                    publishedNodes.TryGetValue(pair.Key, out var published) && ParametersSignature(published) != ParametersSignature(pair.Value))
                    throw new InvalidOperationException("结构同步同时发现事务外参数修改，不能覆盖；草稿保留。");
            if (!formal.GlobalVariables.Select(VariableMetadataSignature).SequenceEqual(_design.GlobalVariables.Select(VariableMetadataSignature)))
                throw new InvalidOperationException("结构同步不能接受事务外变量定义修改。");
            var previousNodes = _nodeInstances.ToArray();
            var retained = currentNodes.Where(p => _nodeInstances.TryGetValue(p.Key, out var original) && ReferenceEquals(original, p.Value) &&
                publishedNodes.TryGetValue(p.Key, out var published) && published.ToolType == p.Value.ToolType).Select(p => p.Key).ToHashSet();
            var projection = new Projection();
            try
            {
                _nodeInstances.Clear(); foreach (var pair in currentNodes) _nodeInstances.Add(pair.Key, pair.Value);
                _store.RebaseStructure(_design, retained, snapshot => AcceptProjection(snapshot, null, projection));
                _structureNotifications.AddRange(projection.Notifications);
            }
            catch
            {
                projection.Restore(this);
                _nodeInstances.Clear(); foreach (var pair in previousNodes) _nodeInstances.Add(pair.Key, pair.Value);
                throw;
            }
            finally { ReleaseProjection(projection); }
            formal = _store.Capture().CopyConfiguration();
        }
        if (_variableCollection.Any(v => !_variableInstances.TryGetValue(v.Id, out var original) || !ReferenceEquals(original, v)))
            throw new InvalidOperationException("正式变量实例已在编辑事务之外变化。");
        if (ShapeSignature(formal) != ShapeSignature(_design))
            throw new InvalidOperationException("正式方案在编辑事务之外发生变化，不能覆盖；请重新建立编辑基线。");
    }
    private void FlushStructureNotifications()
    {
        if (Monitor.IsEntered(_gate)) return;
        List<(GlobalVariable Variable, bool ValueChanged)> notifications;
        lock (_gate) { notifications = _structureNotifications.ToList(); _structureNotifications.Clear(); }
        if (notifications.Count != 0) Emit(notifications);
        Workflow[] roots;lock(_gate){roots=_rootNotifications.ToArray();_rootNotifications.Clear();}
        var errors=new List<Exception>();foreach(var root in roots)try{root.EmitRootConfigurationChanged();}catch(Exception error){errors.Add(error);}
        if(errors.Count!=0)lock(_gate)_lastRefreshError=new AggregateException("根配置已发布，但部分视图通知失败。",errors);
    }
    private static string VariableMetadataSignature(GlobalVariable variable) => JsonSerializer.Serialize(new {
        variable.Id, variable.Name, variable.Type, variable.Group, variable.Index, variable.Description, variable.AdditionalData
    }, WorkflowSerializationOptions.Compact);
    private static string StructureSignature(Solution model) => JsonSerializer.Serialize(new {
        model.Id, Workflows = model.Workflows.Select(w => new { w.Id, w.Name, w.IsSubroutine, w.WorkspaceSettings, w.AdditionalData,
            Nodes = w.Nodes.Select(n => new { n.Id, n.Name, n.DispName, n.ToolType, n.SubroutineId, n.IsEnabled,
                n.PositionX, n.PositionY, n.Width, n.Height, n.GlobalIndex, n.LocalIndex }),
            Connections = w.Connections.Select(c => new { c.Id, c.SourceNodeId, c.SourcePort, c.TargetNodeId, c.TargetPort, c.ManualPathPoints }) })
    }, WorkflowSerializationOptions.Compact);

    private static string ShapeSignature(Solution model) => JsonSerializer.Serialize(new
    {
        model.Id,
        Workflows = model.Workflows.Select(w => new { w.Id, w.IsSubroutine, w.RootConfiguration,
            Nodes = w.Nodes.Select(n => new { n.Id, Signature = NodeEditSignature(n) }),
            Connections = w.Connections.Select(c => new { c.Id, c.SourceNodeId, c.SourcePort, c.TargetNodeId, c.TargetPort, c.ManualPathPoints }) }),
        Variables = model.GlobalVariables.Select(VariableConfigurationSignature)
    }, WorkflowSerializationOptions.Compact);

    private static string NodeEditSignature(WorkflowNodeBase node) => JsonSerializer.Serialize(new
    {
        node.Name, node.DispName, node.ToolType, node.SubroutineId, node.IsEnabled,
        Parameters = ParametersSignature(node)
    }, WorkflowSerializationOptions.Compact);
    private static string ParametersSignature(WorkflowNodeBase node) => JsonSerializer.Serialize(new
    {
        Tool = ToolConfigurationSignature(node)
    }, WorkflowSerializationOptions.Compact);
    private static string ToolConfigurationSignature(WorkflowNodeBase node) => JsonSerializer.Serialize(new
    {
        Type = node.RuntimeConfiguration?.SettingsType.FullName,
        Runtime = node.RuntimeConfiguration?.ConfigurationIdentity,
    }, WorkflowSerializationOptions.Compact);
    private static string VariableConfigurationSignature(GlobalVariable variable) => JsonSerializer.Serialize(new
    {
        variable.Id, variable.Name, variable.Type, variable.Group, variable.Index, variable.Description,
        variable.ProducerBinding, variable.ConsumerBindings, variable.RebindingReason, variable.BindingValidationPending,
        variable.AdditionalData
    }, WorkflowSerializationOptions.Compact);
    private static string VariableDraftStructure(Solution model) => JsonSerializer.Serialize(new
    {
        model.Id, model.Name, model.Description, model.SchemaVersion, model.Version,
        Workflows = model.Workflows.Select(w => new { w.Id, w.Name, w.IsSubroutine,
            Nodes = w.Nodes.Select(n => new { n.Id, n.Name, n.DispName, n.ToolType, n.SubroutineId, n.IsEnabled,
                n.GlobalIndex, n.LocalIndex, n.PositionX, n.PositionY, n.Width, n.Height, n.SelectedDisplayReference }),
            Connections = w.Connections.Select(c => new { c.Id, c.SourceNodeId, c.SourcePort, c.TargetNodeId, c.TargetPort, c.ManualPathPoints }) })
    }, WorkflowSerializationOptions.Compact);
    private static bool SameEditableValue(object? a, object? b) => JsonSerializer.Serialize(new { Type = a?.GetType().FullName, Value = a }, WorkflowSerializationOptions.Compact)
        == JsonSerializer.Serialize(new { Type = b?.GetType().FullName, Value = b }, WorkflowSerializationOptions.Compact);
    private static GlobalVariable CopyVariable(GlobalVariable variable)
    {
        var shell = new Solution(); shell.GlobalVariables.Add(variable);
        return BindingConfigurationStore.Copy(shell).GlobalVariables[0];
    }
    private static Dictionary<ScopedNodeIdentity, WorkflowNodeBase> Nodes(Solution model) => model.Workflows
        .SelectMany(w => w.Nodes.Select(n => (Identity: new ScopedNodeIdentity(w.Id, n.Id), Node: n)))
        .ToDictionary(p => p.Identity, p => p.Node);
    private static WorkflowNodeBase Find(Solution configuration, ScopedNodeIdentity identity) =>
        configuration.Workflows.SingleOrDefault(w => w.Id == identity.WorkflowId)?.Nodes.SingleOrDefault(n => n.Id == identity.NodeId)
        ?? throw new InvalidOperationException("编辑来源节点已删除。");
    private static void SetParameters(WorkflowNodeBase target, WorkflowNodeBase source)
    {
        target.RuntimeConfiguration = source.RuntimeConfiguration?.Copy();

    }
    private static T Copy<T>(T value) => JsonSerializer.Deserialize<T>(JsonSerializer.Serialize(value, WorkflowSerializationOptions.Compact), WorkflowSerializationOptions.Compact)
        ?? throw new InvalidOperationException("无法复制编辑绑定设置。");
}
