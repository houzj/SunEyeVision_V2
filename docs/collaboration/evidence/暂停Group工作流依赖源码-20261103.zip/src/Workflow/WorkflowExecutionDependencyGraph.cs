using System;
using System.Collections.Generic;
using System.Linq;
using SunEyeVision.Plugin.SDK.Execution.Parameters;

namespace SunEyeVision.Workflow;

/// <summary>
/// 由运行计划编译出的节点依赖图。
/// 除画布连接外，也包含参数绑定引用；后续并发调度只能消费此图，不能只看画布连线。
/// </summary>
public sealed class WorkflowExecutionDependencyGraph
{
    private readonly Dictionary<string, HashSet<string>> _predecessors;
    private readonly List<WorkflowExecutionDependency> _dependencies;

    private WorkflowExecutionDependencyGraph(
        Dictionary<string, HashSet<string>> predecessors,
        List<WorkflowExecutionDependency> dependencies)
    {
        _predecessors = predecessors;
        _dependencies = dependencies;
    }

    public IReadOnlyList<WorkflowExecutionDependency> Dependencies => _dependencies;
    public IReadOnlyDictionary<string, IReadOnlyList<ExecutionInputIssue>> InputIssues { get; private set; }
        = new Dictionary<string, IReadOnlyList<ExecutionInputIssue>>();
    internal void AddInputIssues(IReadOnlyDictionary<string,IReadOnlyList<ExecutionInputIssue>> additional)
    {
        var merged=InputIssues.ToDictionary(p=>p.Key,p=>p.Value,StringComparer.Ordinal);
        foreach(var item in additional)merged[item.Key]=merged.TryGetValue(item.Key,out var existing)?existing.Concat(item.Value).Distinct().ToArray():item.Value;
        InputIssues=merged;
    }

    public IReadOnlyCollection<string> GetPredecessors(string nodeId) =>
        _predecessors.TryGetValue(nodeId, out var predecessors)
            ? predecessors
            : Array.Empty<string>();

    /// <summary>以稳定节点顺序生成拓扑层，仅供诊断和后续调度器使用。</summary>
    public IReadOnlyList<IReadOnlyList<string>> GetTopologicalLayers(IEnumerable<string> stableNodeOrder)
    {
        var ordered = stableNodeOrder.Distinct().ToList();
        var orderIndex = ordered
            .Select((id, index) => (id, index))
            .ToDictionary(x => x.id, x => x.index);
        var remaining = _predecessors.ToDictionary(
            pair => pair.Key,
            pair => new HashSet<string>(pair.Value));
        var layers = new List<IReadOnlyList<string>>();

        while (remaining.Count > 0)
        {
            var ready = remaining
                .Where(pair => pair.Value.Count == 0)
                .Select(pair => pair.Key)
                .OrderBy(id => orderIndex.TryGetValue(id, out var index) ? index : int.MaxValue)
                .ThenBy(id => id, StringComparer.Ordinal)
                .ToList();

            if (ready.Count == 0)
                throw new InvalidOperationException("执行依赖图存在循环，无法生成拓扑层。");

            layers.Add(ready);
            foreach (var nodeId in ready)
                remaining.Remove(nodeId);
            foreach (var predecessors in remaining.Values)
                predecessors.ExceptWith(ready);
        }

        return layers;
    }

    public static WorkflowExecutionDependencyGraph Compile(Workflow workflow,
        IReadOnlyList<SunEyeVision.Plugin.SDK.Models.Communication.ReceiveVariableSource>? variables = null, string? sourceWorkflowId = null)
        => Compile(workflow, variables, sourceWorkflowId, null);

    public static WorkflowExecutionDependencyGraph Compile(Workflow workflow,
        IReadOnlyList<SunEyeVision.Plugin.SDK.Models.Communication.ReceiveVariableSource>? variables, string? sourceWorkflowId,
        IReadOnlyDictionary<string, IReadOnlyList<ExecutionInputIssue>>? inputIssues,string? solutionId=null)
    {
        if (workflow == null)
            throw new ArgumentNullException(nameof(workflow));

        var nodeIds = workflow.Nodes.Select(node => node.Id).ToList();
        if (nodeIds.Any(string.IsNullOrWhiteSpace) || nodeIds.Distinct(StringComparer.Ordinal).Count() != nodeIds.Count)
            throw new InvalidOperationException("工作流存在空节点 ID 或重复节点 ID，无法编译执行依赖图。");

        var knownNodes = new HashSet<string>(nodeIds, StringComparer.Ordinal);
        var predecessors = nodeIds.ToDictionary(
            nodeId => nodeId,
            _ => new HashSet<string>(StringComparer.Ordinal),
            StringComparer.Ordinal);
        var dependencies = new List<WorkflowExecutionDependency>();
        var retainedIssues=(inputIssues??new Dictionary<string,IReadOnlyList<ExecutionInputIssue>>()).ToDictionary(pair=>pair.Key,pair=>pair.Value.ToList(),StringComparer.Ordinal);

        void AddDependency(string sourceNodeId, string targetNodeId, WorkflowDependencyKind kind, string? parameterName = null)
        {
            if (!knownNodes.Contains(sourceNodeId) || !knownNodes.Contains(targetNodeId))
                throw new InvalidOperationException(
                    $"执行依赖引用了不存在的节点：{sourceNodeId} → {targetNodeId}。");
            if (string.Equals(sourceNodeId, targetNodeId, StringComparison.Ordinal))
                throw new InvalidOperationException($"节点 {targetNodeId} 不能依赖自身。");

            if (predecessors[targetNodeId].Add(sourceNodeId))
                dependencies.Add(new WorkflowExecutionDependency(sourceNodeId, targetNodeId, kind, parameterName));
        }

        // A deleted Runtime producer remains an explicit field identity, not a fictitious graph node.
        // Preserve every existing dependency for cycle detection; readiness rejects only the missing field.
        void AddRuntimeDependency(string source,string target,string field)
        {
            if(knownNodes.Contains(source)){AddDependency(source,target,WorkflowDependencyKind.ParameterBinding,field);return;}
            if(!retainedIssues.TryGetValue(target,out var issues))retainedIssues[target]=issues=new();
            var issue=new ExecutionInputIssue(field,field,"订阅来源节点不存在："+source);
            if(!issues.Contains(issue))issues.Add(issue);
        }
        foreach (var connection in workflow.Connections)
            AddDependency(connection.SourceNodeId, connection.TargetNodeId, WorkflowDependencyKind.Connection);

        foreach (var node in workflow.Nodes)
        {
            foreach(var (fieldId,setting) in BindingRelationCatalog.References(node,executionOnly:true))
            {
                if(inputIssues?.TryGetValue(node.Id,out var failures)==true&&failures.Any(f=>f.InputKey==fieldId))continue;
                var reference=setting.Reference;
                foreach(var dependency in WorkflowBindingContext.ReferenceNodes(reference,sourceWorkflowId??workflow.Id))
                {
                    if(dependency.ScopeId!=(sourceWorkflowId??workflow.Id))throw new InvalidOperationException("Typed binding crosses the workflow scope.");
                    AddRuntimeDependency(dependency.NodeId,node.Id,fieldId);
                }
            }
            if(node.RuntimeConfiguration is not null)
                foreach(var (fieldId,reference) in BindingRelationCatalog.VariableReferences(node,executionOnly:true))
                {
                    if(reference.SolutionId!=solutionId)continue;
                    var variable=variables?.FirstOrDefault(item=>item.Id==reference.VariableId);
                    if(variable is {HasProducer:true}&&knownNodes.Contains(variable.ProducerNodeId)
                        &&(string.IsNullOrEmpty(variable.ProducerWorkflowId)||variable.ProducerWorkflowId==(sourceWorkflowId??workflow.Id)))
                        AddDependency(variable.ProducerNodeId,node.Id,WorkflowDependencyKind.ParameterBinding,fieldId);
                    if(reference.Selection is SunEyeVision.Plugin.Contracts.BindingSelection.AtField index)
                        foreach(var dependency in WorkflowBindingContext.ReferenceNodes(index.Reference,sourceWorkflowId??workflow.Id))
                        {
                            if(dependency.ScopeId!=(sourceWorkflowId??workflow.Id))throw new InvalidOperationException("变量动态索引跨出工作流作用域。");
                            AddRuntimeDependency(dependency.NodeId,node.Id,fieldId);
                        }
                }
        }

        var graph = new WorkflowExecutionDependencyGraph(predecessors, dependencies)
        { InputIssues = retainedIssues.ToDictionary(pair=>pair.Key,pair=>(IReadOnlyList<ExecutionInputIssue>)pair.Value.AsReadOnly(),StringComparer.Ordinal) };
        graph.GetTopologicalLayers(nodeIds);
        return graph;
    }
}

public enum WorkflowDependencyKind
{
    Connection,
    ParameterBinding
}

public sealed record WorkflowExecutionDependency(
    string SourceNodeId,
    string TargetNodeId,
    WorkflowDependencyKind Kind,
    string? ParameterName);
